<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Metodo nao permitido']);
    exit;
}

// Rate limiting: máximo 5 envios por IP a cada 60 segundos
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$rateFile = sys_get_temp_dir() . '/sp_rate_' . md5($ip) . '.json';
$rateLimit = 5;
$rateWindow = 60;
$now = time();
$rateData = ['count' => 0, 'window_start' => $now];
if (file_exists($rateFile)) {
    $stored = @json_decode(file_get_contents($rateFile), true);
    if (is_array($stored) && isset($stored['window_start'])) {
        if ($now - $stored['window_start'] < $rateWindow) {
            $rateData = $stored;
        }
    }
}
if ($rateData['count'] >= $rateLimit) {
    http_response_code(429);
    echo json_encode(['error' => 'Muitas tentativas. Aguarde um momento.']);
    exit;
}
$rateData['count']++;
@file_put_contents($rateFile, json_encode($rateData), LOCK_EX);

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!is_array($data)) {
    $data = $_POST;
}

// Honeypot: campo oculto que só bots preenchem
$honeypot = trim((string)($data['website'] ?? ''));
if ($honeypot !== '') {
    http_response_code(400);
    echo json_encode(['error' => 'Requisicao invalida.']);
    exit;
}

$nome = trim((string)($data['nome'] ?? ''));
$telefone = trim((string)($data['telefone'] ?? ''));
$produto = trim((string)($data['produto'] ?? 'Nao informado'));
$mensagem = trim((string)($data['mensagem'] ?? ''));

if ($nome === '' || $telefone === '' || $mensagem === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Preencha nome, telefone e mensagem.']);
    exit;
}

$nome = str_replace(["\r", "\n"], ' ', $nome);
$telefone = str_replace(["\r", "\n"], ' ', $telefone);
$produto = str_replace(["\r", "\n"], ' ', $produto);

$destinatario = 'contato@superiorplast.com.br';
$assunto = 'Orcamento - Superior Plast';
$dominio = $_SERVER['HTTP_HOST'] ?? 'localhost';
$dominio = preg_replace('/^www\./i', '', $dominio);
$fromEmail = 'contato@superiorplast.com.br';

$corpo = "Nova solicitacao pelo site\n\n" .
    "Nome: {$nome}\n" .
    "Telefone: {$telefone}\n" .
    "Produto: {$produto}\n" .
    "Mensagem: {$mensagem}\n";

$headers = [
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    "From: Superior Plast <{$fromEmail}>",
    "Reply-To: Superior Plast <{$destinatario}>",
    'X-Mailer: PHP/' . phpversion(),
];

if (!function_exists('mail')) {
    http_response_code(500);
    echo json_encode(['error' => 'A funcao mail() nao esta habilitada na hospedagem.']);
    exit;
}

$enviado = @mail($destinatario, $assunto, $corpo, implode("\r\n", $headers), "-f{$fromEmail}");

if (!$enviado) {
    http_response_code(500);
    echo json_encode(['error' => 'Falha ao enviar pelo servidor. Verifique o email do dominio na hospedagem.']);
    exit;
}

echo json_encode(['message' => 'Mensagem enviada com sucesso!']);
